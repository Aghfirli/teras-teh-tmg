
// teras teh tmg - PWA web app (offline-friendly)
(() => {
  const LS_PRODUCTS = 'ttt_products_v1';
  const LS_ORDERS = 'ttt_orders_v1';

  const sampleProducts = [
    { id: 'p1', name: 'Jasmin Tea', price: 3000, stock: 100 },
    { id: 'p2', name: 'Lychee Tea', price: 5000, stock: 100 },
    { id: 'p3', name: 'Strawberry Tea', price: 5000, stock: 100 },
    { id: 'p4', name: 'Melon Tea', price: 5000, stock: 100 },
    { id: 'p5', name: 'Lemon Tea', price: 5000, stock: 100 },
    { id: 'p6', name: 'Mango Tea', price: 5000, stock: 100 },
    { id: 'p7', name: 'Thai Tea', price: 5000, stock: 100 },
    { id: 'p8', name: 'Ice Blend Mangga', price: 10000, stock: 100 },
    { id: 'p9', name: 'Ice Blend Coklat', price: 10000, stock: 100 },
    { id: 'p10', name: 'Ice Blend Matcha', price: 13000, stock: 100 },
    { id: 'p11', name: 'Ice Blend Taro', price: 10000, stock: 100 },
    { id: 'p12', name: 'Ice Blend Bubblegum', price: 10000, stock: 100 },
    { id: 'p13', name: 'Ice Blend Vanilla', price: 10000, stock: 100 },
    { id: 'p14', name: 'Coco Magnum', price: 15000, stock: 100 },
    { id: 'p15', name: 'Ice Blend Red Velvet', price: 10000, stock: 100 },
    { id: 'p16', name: 'Ice Blend Strawberry', price: 10000, stock: 100 },
    { id: 'p17', name: 'Strawberry Yakult', price: 9000, stock: 100 },
    { id: 'p18', name: 'Mangga Yakult', price: 9000, stock: 100 },
    { id: 'p19', name: 'Melon Yakult', price: 9000, stock: 100 },
    { id: 'p20', name: 'Lychee Yakult', price: 9000, stock: 100 },
    { id: 'p21', name: 'Lemon Yakult', price: 9000, stock: 100 },
    { id: 'p22', name: 'Cappuccino Special', price: 15000, stock: 100 },
    { id: 'p23', name: 'Tiramisu', price: 13000, stock: 100 },
    { id: 'p24', name: 'Vanilla Latte', price: 13000, stock: 100 },
    { id: 'p25', name: 'Hazelnut', price: 13000, stock: 100 },
    { id: 'p26', name: 'Coffee Caramel', price: 13000, stock: 100 }
  ];

  const qs = s => document.querySelector(s);

  let products = load(LS_PRODUCTS) || sampleProducts;
  let orders = load(LS_ORDERS) || [];
  let cart = [];

  const productsGrid = qs('#products-grid');
  const cartList = qs('#cart-list');
  const cartTotal = qs('#cart-total');
  const checkoutBtn = qs('#checkout-cash');
  const clearCartBtn = qs('#clear-cart');
  const ordersList = qs('#orders-list');
  const ordersSection = qs('#orders-section');

  // render products grid
  function renderProducts(){
    productsGrid.innerHTML = '';
    products.forEach(p => {
      const card = document.createElement('div');
      card.className = 'card';
      card.innerHTML = `<div>
          <div class="name">${escapeHtml(p.name)}</div>
          <div class="price">${formatRp(p.price)}</div>
          <div class="stock">Stok: ${p.stock}</div>
        </div>
        <div>
          <button class="btn primary add-btn" data-id="${p.id}">Tambah</button>
        </div>`;
      productsGrid.appendChild(card);
    });
    productsGrid.querySelectorAll('.add-btn').forEach(b => b.addEventListener('click', (e)=> addToCart(e.target.dataset.id)));
  }

  function renderCart(){
    cartList.innerHTML = '';
    if(cart.length === 0){ cartList.textContent = 'Keranjang kosong'; cartTotal.textContent = formatRp(0); return; }
    cart.forEach(item => {
      const div = document.createElement('div');
      div.className = 'cart-item';
      div.innerHTML = `<div>${escapeHtml(item.name)} x ${item.qty}</div><div>${formatRp(item.price*item.qty)}</div>`;
      cartList.appendChild(div);
    });
    cartTotal.textContent = formatRp(cart.reduce((s,i)=> s + i.price*i.qty, 0));
  }

  function addToCart(id){
    const p = products.find(x=>x.id===id);
    if(!p || p.stock <= 0){ alert('Stok habis'); return; }
    const found = cart.find(i=>i.id===id);
    if(found) found.qty = Math.min(found.qty + 1, p.stock);
    else cart.push({ id: p.id, name: p.name, price: p.price, qty: 1 });
    renderCart();
  }

  function checkout(){
    if(cart.length === 0){ alert('Keranjang kosong'); return; }
    // simple stock check
    for(const it of cart){ const p = products.find(x=>x.id===it.id); if(!p || p.stock < it.qty){ alert('Stok tidak cukup untuk ' + it.name); return; } }
    const total = cart.reduce((s,i)=> s + i.price*i.qty, 0);
    const order = { id: 'o' + Date.now(), date: new Date().toISOString(), items: cart.slice(), total };
    orders.unshift(order);
    // decrement stock
    products = products.map(p => { const it = cart.find(c=>c.id===p.id); if(!it) return p; return { ...p, stock: Math.max(0, p.stock - it.qty) }; });
    cart = [];
    save(LS_ORDERS, orders); save(LS_PRODUCTS, products);
    renderProducts(); renderCart(); renderOrders();
    alert('Transaksi berhasil: ' + formatRp(total));
    ordersSection.classList.remove('hidden');
  }

  function renderOrders(){
    ordersList.innerHTML = '';
    if(orders.length === 0){ ordersList.textContent = 'Belum ada transaksi'; return; }
    orders.forEach(o => {
      const div = document.createElement('div');
      div.className = 'order-card';
      div.innerHTML = `<div><strong>${o.id}</strong> — ${new Date(o.date).toLocaleString()}</div><div>Total: ${formatRp(o.total)}</div>
        <div>${o.items.map(it => `${escapeHtml(it.name)} x ${it.qty} — ${formatRp(it.price*it.qty)}`).join('<br>')}</div>`;
      ordersList.appendChild(div);
    });
  }

  checkoutBtn.addEventListener('click', checkout);
  clearCartBtn.addEventListener('click', ()=> { cart = []; renderCart(); });

  // initial render
  renderProducts();
  renderCart();
  renderOrders();

  // localStorage helpers
  function save(key, v){ localStorage.setItem(key, JSON.stringify(v)); }
  function load(key){ try{ const s = localStorage.getItem(key); return s ? JSON.parse(s) : null; }catch(e){ return null; } }
  function formatRp(n){ if(!n) return 'Rp0'; return new Intl.NumberFormat('id-ID',{style:'currency',currency:'IDR',maximumFractionDigits:0}).format(n); }
  function escapeHtml(s){ return String(s).replace(/[&<>"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c])); }

  // Install prompt for PWA (optional)
  let deferredPrompt;
  const installBtn = qs('#install-btn');
  window.addEventListener('beforeinstallprompt', (e) => {
    e.preventDefault();
    deferredPrompt = e;
    installBtn.hidden = false;
    installBtn.addEventListener('click', async () => {
      installBtn.hidden = true;
      deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      deferredPrompt = null;
    });
  });
})();
