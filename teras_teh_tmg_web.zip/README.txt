Teras Teh TMG - Web App (PWA)
============================

Files included:
- index.html
- css/styles.css
- js/app.js
- manifest.json
- sw.js

Cara pakai (lokal):
1. Ekstrak folder ini dan buka file index.html di browser untuk testing.
2. Untuk PWA terbaik (installable), tempatkan file di web server (GitHub Pages, Netlify, atau hosting lain).
3. Setelah dihosting, buka di browser (Chrome/Edge/Firefox Android), kamu bisa menambahkan ke Home Screen (Install) dan aplikasi akan berjalan offline.

Perubahan:
- Tema berwarna putih sesuai permintaan.
- Nama aplikasi: 'teras teh tmg'.
- Menu default sesuai daftar yang diminta.
